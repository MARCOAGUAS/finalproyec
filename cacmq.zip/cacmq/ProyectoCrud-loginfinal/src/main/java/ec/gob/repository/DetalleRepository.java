package ec.gob.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.gob.model.Detalle;

public interface DetalleRepository extends JpaRepository<Detalle, Integer> {

}
