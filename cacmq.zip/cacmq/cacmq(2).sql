-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 16-11-2019 a las 09:04:13
-- Versión del servidor: 5.6.45
-- Versión de PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cacmq`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `authorities`
--

CREATE TABLE IF NOT EXISTS `authorities` (
  `username` varchar(50) NOT NULL,
  `authority` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `authorities`
--

INSERT INTO `authorities` (`username`, `authority`) VALUES
('admin', 'ADMIN'),
('henry', 'AGENTE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles`
--

CREATE TABLE IF NOT EXISTS `detalles` (
  `id` int(11) NOT NULL,
  `responsable` varchar(50) NOT NULL,
  `resumen` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalles`
--

INSERT INTO `detalles` (`id`, `responsable`, `resumen`) VALUES
(17, 'alfonso', 'edtrfyguhiojpklñ'),
(18, 'alfonso', 'edtrfyguhiojpklñ'),
(20, 'juan', 'tyuio'),
(25, 'henry', 'edtrfyguhiojpklñ'),
(26, 'daniel', 'prueba de consola'),
(27, 'henry', 'edtrfyguhiojpklñ'),
(28, 'sdf', 'wert');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarioOperativos`
--

CREATE TABLE IF NOT EXISTS `horarioOperativos` (
  `idhora` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `lugar` varchar(100) NOT NULL,
  `efectivos` int(11) NOT NULL,
  `idoperativo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oficios`
--

CREATE TABLE IF NOT EXISTS `oficios` (
  `id` int(11) NOT NULL,
  `numeroDoc` int(11) NOT NULL,
  `solicitante` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `detalle` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `oficios`
--

INSERT INTO `oficios` (`id`, `numeroDoc`, `solicitante`, `fecha`, `detalle`) VALUES
(8, 23, 'prueba', '2019-11-10', 'prueba de consola '),
(9, 23, 'alfonso', '2019-11-10', 'prueba de consola '),
(10, 0, 'er', '2019-11-10', 'prueba de consola '),
(11, 0, 'er', '2019-11-10', 'prueba de consola '),
(12, 1, 'yu', '2019-11-19', 'hgnjm'),
(13, 0, 'k', '2019-11-26', 'm'),
(14, 2, 'alma', '2019-11-19', 'res'),
(15, 23, 'carlos', '2019-11-27', 'pedido de canes'),
(16, 1, 'prueba', '2019-11-10', 'prueba de consola '),
(17, 0, 'prueba', '2019-11-10', 'prueba de consola 2'),
(18, 11, 'prueba', '2019-11-10', 'prueba de consola ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Operativo`
--

CREATE TABLE IF NOT EXISTS `Operativo` (
  `id` int(11) NOT NULL,
  `eventosControlados` int(11) NOT NULL,
  `disuacionAcogPerso` int(11) NOT NULL,
  `AprenDelin` int(11) NOT NULL,
  `infoturis` int(11) NOT NULL,
  `AprenGrafi` int(11) NOT NULL,
  `operAmc` int(11) NOT NULL,
  `retenciones` int(11) NOT NULL,
  `personasEncontadas` int(11) NOT NULL,
  `sitioClausurados` int(11) NOT NULL,
  `personaAgredido` int(11) NOT NULL,
  `licoresDecomisados` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `idDetalle` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Operativo`
--

INSERT INTO `Operativo` (`id`, `eventosControlados`, `disuacionAcogPerso`, `AprenDelin`, `infoturis`, `AprenGrafi`, `operAmc`, `retenciones`, `personasEncontadas`, `sitioClausurados`, `personaAgredido`, `licoresDecomisados`, `fecha`, `idDetalle`) VALUES
(17, 1, 111, 1, 1, 1, 1, 1, 1, 1, 1, 11, '2019-11-16', 17),
(18, 123, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2019-11-27', 18),
(20, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, '2019-11-05', 20),
(25, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, '2019-11-27', 25),
(26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2019-11-08', 26),
(27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2019-11-27', 27),
(28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2019-11-29', 28);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE IF NOT EXISTS `persona` (
  `id` int(11) NOT NULL,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` int(11) NOT NULL,
  `sexo` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`id`, `nombres`, `apellidos`, `fecha`, `direccion`, `telefono`, `sexo`) VALUES
(1, 'Pamela', 'Criollo', '1998-07-09', 'San Carlos', 99009999, 'Femenino'),
(2, 'carlos', 'Alvares', '2019-11-06', 'quitumbe', 67890, 'masculino'),
(3, 'Vanesa', 'Tonato', '2019-11-06', 'quitumbe', 67890, 'femenino'),
(4, 'Edison', 'Fausto', '2019-11-06', 'San Martin', 67890, 'masculino');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `enabled` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`username`, `password`, `enabled`) VALUES
('admin', '{noop}admin123', 1),
('henry', '{noop}henry123', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `authorities`
--
ALTER TABLE `authorities`
  ADD UNIQUE KEY `authorities_idx_1` (`username`,`authority`);

--
-- Indices de la tabla `detalles`
--
ALTER TABLE `detalles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `horarioOperativos`
--
ALTER TABLE `horarioOperativos`
  ADD PRIMARY KEY (`idhora`),
  ADD KEY `idoperativo` (`idoperativo`);

--
-- Indices de la tabla `oficios`
--
ALTER TABLE `oficios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `Operativo`
--
ALTER TABLE `Operativo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_detalle` (`idDetalle`),
  ADD KEY `idDetalle` (`idDetalle`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalles`
--
ALTER TABLE `detalles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT de la tabla `horarioOperativos`
--
ALTER TABLE `horarioOperativos`
  MODIFY `idhora` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `oficios`
--
ALTER TABLE `oficios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de la tabla `Operativo`
--
ALTER TABLE `Operativo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT de la tabla `persona`
--
ALTER TABLE `persona`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `authorities`
--
ALTER TABLE `authorities`
  ADD CONSTRAINT `authorities_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`);

--
-- Filtros para la tabla `horarioOperativos`
--
ALTER TABLE `horarioOperativos`
  ADD CONSTRAINT `horarioOperativos_ibfk_1` FOREIGN KEY (`idoperativo`) REFERENCES `Operativo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `Operativo`
--
ALTER TABLE `Operativo`
  ADD CONSTRAINT `Operativo_ibfk_1` FOREIGN KEY (`idDetalle`) REFERENCES `detalles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
